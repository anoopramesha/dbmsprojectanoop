/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelgo;

/**
 *
 * @author arjunhm
 */
public class hotelgo {
    public static String cname;
    public static String cid;
    public static String price;
    
    public static String bookingHotelID;
    public static String bookingCheckIn;
    public static String bookingCheckOut;
    public static String bookingRoomType;
    public static String bookingCount;
    public static String bookingAmount;
    public static String bookingBookingID;
    
    public static String modifyBookingID;
    public static String modifyHotelID;
    public static String modifyBasicRoomCount;
    public static String modifyDeluxeRoomCount;
    public static String modifyExecRoomCount;
    public static String modifyCheckIn;
    public static String modifyCheckOut;
    public static String modifyCount;
    
    public static String mgrID;
    
    public static void main(String[] args) {}
}


